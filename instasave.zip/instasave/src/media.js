'use strict';

const { spawn } = require('node:child_process');
const sharp = require('sharp');
const { AppError } = require('./errors');

const IMAGE_TARGETS = ['jpg', 'png', 'webp'];
const VIDEO_TARGETS = ['mp4', 'webm', 'mp3'];
// ffmpeg encoders each output format needs
const REQUIRED_ENCODERS = {
  mp4: ['libx264', 'aac'],
  webm: ['libvpx-vp9', 'libopus'],
  mp3: ['libmp3lame'],
};
const OUTPUT_MIME = {
  jpg: ['image/jpeg', 'image'],
  png: ['image/png', 'image'],
  webp: ['image/webp', 'image'],
  mp4: ['video/mp4', 'video'],
  webm: ['video/webm', 'video'],
  mp3: ['audio/mpeg', 'audio'],
};

/**
 * Identify a file from its first bytes. The file name and the browser-reported
 * type are never trusted. Returns null for anything that is not a supported image/video.
 */
function sniff(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { mime: 'image/jpeg', ext: 'jpg', kind: 'image' };
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) {
    return { mime: 'image/png', ext: 'png', kind: 'image' };
  }
  const head6 = buf.toString('latin1', 0, 6);
  if (head6 === 'GIF87a' || head6 === 'GIF89a') return { mime: 'image/gif', ext: 'gif', kind: 'image' };
  if (buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') {
    return { mime: 'image/webp', ext: 'webp', kind: 'image' };
  }
  if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) {
    return { mime: 'video/webm', ext: 'webm', kind: 'video' };
  }
  if (buf.toString('latin1', 4, 8) === 'ftyp') {
    const brand = buf.toString('latin1', 8, 12);
    if (/^(heic|heix|hevc|hevx|heim|heis|mif1|msf1|avif|avis|M4A |M4B |M4P )$/.test(brand)) return null;
    if (brand === 'qt  ') return { mime: 'video/quicktime', ext: 'mov', kind: 'video' };
    return { mime: 'video/mp4', ext: 'mp4', kind: 'video' };
  }
  return null;
}

function run(cmd, args, { timeoutMs, collectStdout = false }) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { stdio: ['ignore', collectStdout ? 'pipe' : 'ignore', 'pipe'], shell: false });
    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new AppError(422, 'CONVERSION_TIMEOUT', 'The conversion took too long and was stopped.'));
    }, timeoutMs);
    if (collectStdout) child.stdout.on('data', (d) => (stdout += d));
    child.stderr.on('data', (d) => (stderr = (stderr + d).slice(-2000)));
    child.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0) resolve(stdout);
      else reject(Object.assign(new Error('ffmpeg exited with ' + code), { stderr }));
    });
  });
}

class MediaService {
  constructor(config) {
    this.ffmpegPath = config.ffmpegPath;
    this.timeoutMs = config.convertTimeoutMs;
    this.available = { jpg: true, png: true, webp: true, mp4: false, webm: false, mp3: false };
  }

  /** Detect which ffmpeg encoders exist so the UI only offers formats that work. */
  async init() {
    try {
      const out = await run(this.ffmpegPath, ['-hide_banner', '-encoders'], { timeoutMs: 10000, collectStdout: true });
      for (const [fmt, encoders] of Object.entries(REQUIRED_ENCODERS)) {
        this.available[fmt] = encoders.every((e) => new RegExp(`\\s${e}\\s`).test(out));
      }
    } catch {
      /* ffmpeg is optional */
    }
    return this.available;
  }

  capabilities() {
    return {
      image: IMAGE_TARGETS.filter((f) => this.available[f]),
      video: VIDEO_TARGETS.filter((f) => this.available[f]),
    };
  }

  /** Formats this entry can be converted to (never its own format). */
  targetsFor(entry) {
    if (entry.kind === 'image') return IMAGE_TARGETS.filter((f) => this.available[f] && f !== entry.ext);
    if (entry.kind === 'video') return VIDEO_TARGETS.filter((f) => this.available[f] && f !== entry.ext);
    return [];
  }

  canConvert(entry, format) {
    return this.targetsFor(entry).includes(format);
  }

  static outputInfo(format) {
    const [mime, kind] = OUTPUT_MIME[format];
    return { mime, kind, ext: format };
  }

  /** Confirm an uploaded image really decodes (and is not a decompression bomb). */
  async validateImage(filePath) {
    try {
      const meta = await sharp(filePath, { limitInputPixels: 100_000_000 }).metadata();
      if (!meta.width || !meta.height) throw new Error('no dimensions');
    } catch {
      throw new AppError(415, 'INVALID_IMAGE', 'That image file is corrupted or too large to process.');
    }
  }

  async convert(entry, format, destPath) {
    if (entry.kind === 'image') return this.convertImage(entry.filePath, format, destPath);
    return this.convertVideo(entry.filePath, format, destPath);
  }

  async convertImage(src, format, dest) {
    try {
      let img = sharp(src, { limitInputPixels: 100_000_000 }).rotate();
      if (format === 'jpg') img = img.flatten({ background: '#ffffff' }).jpeg({ quality: 92, mozjpeg: true });
      else if (format === 'png') img = img.png();
      else img = img.webp({ quality: 90 });
      await img.toFile(dest);
    } catch {
      throw new AppError(422, 'CONVERSION_FAILED', 'Could not convert this image. It may be corrupted.');
    }
  }

  async convertVideo(src, format, dest) {
    const base = ['-nostdin', '-hide_banner', '-loglevel', 'error', '-y', '-i', src];
    const args = {
      mp4: ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-c:a', 'aac', '-movflags', '+faststart'],
      webm: ['-c:v', 'libvpx-vp9', '-b:v', '0', '-crf', '33', '-deadline', 'realtime', '-cpu-used', '8', '-c:a', 'libopus'],
      mp3: ['-vn', '-c:a', 'libmp3lame', '-q:a', '2'],
    }[format];
    try {
      await run(this.ffmpegPath, [...base, ...args, '-f', format === 'mp3' ? 'mp3' : format, dest], { timeoutMs: this.timeoutMs });
    } catch (err) {
      if (err instanceof AppError) throw err;
      throw new AppError(422, 'CONVERSION_FAILED', 'Could not convert this file. It may be corrupted or have no usable audio/video.');
    }
  }
}

module.exports = { MediaService, sniff };
