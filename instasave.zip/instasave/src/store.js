'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { AppError } = require('./errors');

const ID_RE = /^[a-f0-9]{32}$/;
// Only files that we created are ever removed from the upload directory.
const OWN_FILE_RE = /^[a-f0-9]{32}\.[a-z0-9]{1,5}(\.part)?$/;

/**
 * Temporary storage for uploads and conversion results.
 * Files get unguessable 128-bit ids, are written with mode 0600 and are deleted after a TTL.
 */
class FileStore {
  constructor({ dir, ttlMs, maxStorageBytes }) {
    this.dir = dir;
    this.ttlMs = ttlMs;
    this.maxStorageBytes = maxStorageBytes;
    this.entries = new Map();
    this.reservedBytes = 0;
    this.timer = null;
  }

  async init() {
    await fs.mkdir(this.dir, { recursive: true, mode: 0o700 });
    // Clear leftovers from a previous run (only files that match our own naming scheme).
    for (const name of await fs.readdir(this.dir)) {
      if (OWN_FILE_RE.test(name)) await fs.rm(path.join(this.dir, name), { force: true });
    }
    this.timer = setInterval(() => this.sweep().catch(() => {}), 30 * 1000);
    this.timer.unref();
  }

  get totalBytes() {
    let total = 0;
    for (const e of this.entries.values()) total += e.size;
    return total;
  }

  assertCapacity(extraBytes) {
    if (this.totalBytes + extraBytes > this.maxStorageBytes) {
      throw new AppError(503, 'STORAGE_FULL', 'The server is temporarily full. Please try again in a few minutes.');
    }
  }

  /** Reserve an id and the paths used for it. */
  reserve(ext = '') {
    const id = crypto.randomBytes(16).toString('hex');
    return {
      id,
      partPath: path.join(this.dir, `${id}.part`),
      filePath: ext ? path.join(this.dir, `${id}.${ext}`) : null,
    };
  }

  add({ id, filePath, name, mime, ext, kind, size }) {
    const entry = { id, filePath, name, mime, ext, kind, size, createdAt: Date.now(), expiresAt: Date.now() + this.ttlMs };
    this.entries.set(id, entry);
    return entry;
  }

  get(id) {
    if (typeof id !== 'string' || !ID_RE.test(id)) return null;
    const e = this.entries.get(id);
    if (!e) return null;
    if (e.expiresAt <= Date.now()) {
      this.remove(id).catch(() => {});
      return null;
    }
    return e;
  }

  async remove(id) {
    const e = this.entries.get(id);
    if (!e) return false;
    this.entries.delete(id);
    await fs.rm(e.filePath, { force: true });
    return true;
  }

  async sweep() {
    const now = Date.now();
    for (const e of [...this.entries.values()]) if (e.expiresAt <= now) await this.remove(e.id);
  }

  async close() {
    clearInterval(this.timer);
    for (const id of [...this.entries.keys()]) await this.remove(id);
  }
}

module.exports = { FileStore };
