'use strict';

const fs = require('node:fs');
const fsp = require('node:fs/promises');
const crypto = require('node:crypto');
const { Readable } = require('node:stream');
const { pipeline } = require('node:stream/promises');
const { AppError } = require('./errors');
const h = require('./http');
const { sniff, MediaService } = require('./media');
const { parseInstagramUrl } = require('../public/js/validators');

const SESSION_COOKIE = 'sid';
const STATE_COOKIE = 'oauth_state';
const UPSTREAM_TYPES = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'video/mp4': 'mp4',
  'video/quicktime': 'mov',
  'video/webm': 'webm',
};

function sanitizeFilename(name) {
  const cleaned = String(name)
    .replace(/[\u0000-\u001f\u007f/\\:*?"<>|]/g, '')
    .replace(/^\.+/, '')
    .trim()
    .slice(0, 120);
  return cleaned || 'upload';
}
const stripExt = (name) => name.replace(/\.[A-Za-z0-9]{1,5}$/, '') || 'file';

/**
 * Builds the HTTP surface of the app. Handlers use only Node-native req/res APIs
 * (plus req.params), so they work with Express and are unit-testable without it.
 */
function createRoutes({ config, sessions, store, instagram, media }) {
  const secure = config.isProd;
  const apiLimit = h.rateLimiter({ windowMs: config.rateLimit.windowMs, max: config.rateLimit.api });
  const heavyLimit = h.rateLimiter({ windowMs: config.rateLimit.windowMs, max: config.rateLimit.heavy });
  let activeConversions = 0;

  const middleware = [h.securityHeaders({ isProd: config.isProd }), h.originCheck(config.baseUrl)];

  const currentSession = (req) => {
    const sid = h.parseCookies(req.headers.cookie)[SESSION_COOKIE];
    return sid ? sessions.get(sid) : null;
  };

  const publicEntry = (e) => ({
    id: e.id,
    name: e.name,
    size: e.size,
    mime: e.mime,
    kind: e.kind,
    ext: e.ext,
    previewUrl: `/api/files/${e.id}/preview`,
    downloadUrl: `/api/files/${e.id}/download`,
    expiresAt: new Date(e.expiresAt).toISOString(),
    convertTo: media.targetsFor(e),
  });

  /* ------------------------------ config & session ------------------------------ */

  function getConfig(req, res) {
    h.sendJson(res, 200, {
      appName: config.appName,
      contactEmail: config.contactEmail || null,
      instagram: { enabled: instagram.enabled },
      upload: { maxMb: Math.floor(config.upload.maxBytes / 1048576), ttlMinutes: Math.round(config.upload.ttlMs / 60000) },
      conversions: media.capabilities(),
    });
  }

  function getSession(req, res) {
    const s = currentSession(req);
    h.sendJson(res, 200, s ? { connected: true, username: s.username, expiresAt: new Date(s.expiresAt).toISOString() } : { connected: false });
  }

  function logout(req, res) {
    const sid = h.parseCookies(req.headers.cookie)[SESSION_COOKIE];
    if (sid) sessions.destroy(sid);
    h.setCookie(res, SESSION_COOKIE, '', { maxAgeSeconds: 0, secure });
    h.sendJson(res, 200, { ok: true });
  }

  /* --------------------------- Instagram OAuth (official) -------------------------- */

  function authStart(req, res) {
    if (!instagram.enabled) return h.redirect(res, '/?auth_error=not_configured');
    const state = h.randomToken(24);
    h.setCookie(res, STATE_COOKIE, state, { maxAgeSeconds: 600, secure });
    h.redirect(res, instagram.buildAuthUrl(state));
  }

  async function authCallback(req, res) {
    const q = h.getQuery(req);
    const expected = h.parseCookies(req.headers.cookie)[STATE_COOKIE];
    h.setCookie(res, STATE_COOKIE, '', { maxAgeSeconds: 0, secure });
    if (!instagram.enabled) return h.redirect(res, '/?auth_error=not_configured');
    if (q.get('error')) return h.redirect(res, '/?auth_error=denied');
    if (!expected || !q.get('state') || !h.safeEqual(expected, q.get('state')) || !q.get('code')) {
      return h.redirect(res, '/?auth_error=state');
    }
    try {
      const { accessToken, expiresAt } = await instagram.exchangeCode(q.get('code'));
      const profile = await instagram.getProfile(accessToken);
      const session = sessions.create({ accessToken, expiresAt, ...profile });
      h.setCookie(res, SESSION_COOKIE, session.id, { maxAgeSeconds: Math.floor((expiresAt - Date.now()) / 1000), secure });
      h.redirect(res, '/?connected=1');
    } catch (err) {
      console.error('[auth] callback failed:', err.message);
      h.redirect(res, '/?auth_error=failed');
    }
  }

  /* ------------------------------ Instagram media ------------------------------- */

  async function resolve(req, res) {
    const body = await h.readJson(req);
    const parsed = parseInstagramUrl(body.url);
    if (!parsed.ok) throw new AppError(400, parsed.code, parsed.message);
    if (!instagram.enabled) {
      throw new AppError(
        503,
        'INSTAGRAM_NOT_CONFIGURED',
        'Instagram connection is not set up on this server. You can still use the upload tool.'
      );
    }
    const session = currentSession(req);
    if (!session) {
      throw new AppError(401, 'AUTH_REQUIRED', 'Connect your Instagram account first. Only media from the account you connect can be downloaded.');
    }

    const found = await instagram.findOwnMedia(session.accessToken, parsed.shortcode);
    if (!found) {
      throw new AppError(
        404,
        'NOT_AVAILABLE',
        `This link was not found among the most recent posts of @${session.username}. InstaSave can only download media from the account you connected, and the official API does not provide access to anyone else's posts.`
      );
    }

    const parts = found.children.length ? found.children : [found];
    const items = [];
    parts.forEach((part, index) => {
      if (!part.mediaUrl) return; // Instagram omits media_url for e.g. copyrighted audio
      const id = crypto.randomBytes(12).toString('hex');
      sessions.addItem(session, id, {
        mediaUrl: part.mediaUrl,
        thumbUrl: part.thumbnailUrl,
        baseName: `instagram-${parsed.shortcode}${parts.length > 1 ? `-${index + 1}` : ''}`,
      });
      items.push({
        id,
        index: index + 1,
        mediaType: part.mediaType,
        formats: [part.mediaType === 'VIDEO' ? 'MP4' : 'JPG'],
        previewUrl: `/api/ig/item/${id}/media`,
        posterUrl: part.thumbnailUrl ? `/api/ig/item/${id}/thumb` : null,
        downloadUrl: `/api/ig/item/${id}/media?download=1`,
      });
    });
    if (!items.length) {
      throw new AppError(422, 'MEDIA_UNAVAILABLE', 'Instagram did not provide a downloadable file for this post (for example, because it contains copyrighted audio).');
    }
    h.sendJson(res, 200, { type: parsed.type, carousel: found.children.length > 1, shortcode: parsed.shortcode, items });
  }

  /** Streams an item of the connected account through our server (keeps the token and CDN URLs private). */
  async function igProxy(req, res) {
    const session = currentSession(req);
    if (!session) throw new AppError(401, 'AUTH_REQUIRED', 'Connect your Instagram account first.');
    const item = session.items.get(req.params.id);
    if (!item) throw new AppError(404, 'NOT_FOUND', 'This item has expired. Please look up the link again.');
    const isThumb = req.params.variant === 'thumb';
    const target = isThumb ? item.thumbUrl || item.mediaUrl : item.mediaUrl;
    if (!config.isAllowedMediaUrl(target)) {
      throw new AppError(502, 'BLOCKED_HOST', 'The media location was rejected for security reasons.');
    }

    const headers = {};
    const range = req.headers.range;
    if (range && /^bytes=\d*-\d*$/.test(range)) headers.Range = range;

    const ac = new AbortController();
    res.on('close', () => ac.abort());
    const connectTimer = setTimeout(() => ac.abort(), 15000);
    let upstream;
    try {
      upstream = await fetch(target, { headers, redirect: 'manual', signal: ac.signal });
    } catch {
      throw new AppError(502, 'UPSTREAM_ERROR', 'Could not download the file from Instagram.');
    } finally {
      clearTimeout(connectTimer);
    }
    const type = (upstream.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
    const ext = UPSTREAM_TYPES[type];
    if ((upstream.status !== 200 && upstream.status !== 206) || !ext || !upstream.body) {
      upstream.body?.cancel().catch(() => {});
      throw new AppError(502, 'UPSTREAM_ERROR', 'Instagram did not return a valid media file.');
    }

    const download = h.getQuery(req).get('download') === '1';
    res.statusCode = upstream.status;
    res.setHeader('Content-Type', type);
    const encoded = upstream.headers.get('content-encoding');
    for (const name of ['content-range', 'accept-ranges', ...(encoded ? [] : ['content-length'])]) {
      const v = upstream.headers.get(name);
      if (v) res.setHeader(name, v);
    }
    res.setHeader('Cache-Control', 'private, max-age=300');
    res.setHeader('Content-Disposition', h.contentDisposition(download ? 'attachment' : 'inline', `${item.baseName}${isThumb ? '-thumb' : ''}.${ext}`));
    await pipeline(Readable.fromWeb(upstream.body), res).catch(() => {});
  }

  /* ------------------------------ uploads & conversion ----------------------------- */

  async function upload(req, res) {
    const max = config.upload.maxBytes;
    let name = 'upload';
    try {
      name = decodeURIComponent(String(req.headers['x-filename'] || 'upload'));
    } catch {
      /* keep default */
    }
    name = sanitizeFilename(name);

    const declared = Number(req.headers['content-length']);
    if (Number.isFinite(declared) && declared > max) {
      throw new AppError(413, 'FILE_TOO_LARGE', `File is larger than the ${Math.floor(max / 1048576)} MB limit.`);
    }
    store.assertCapacity(Number.isFinite(declared) ? declared : max);

    const { id, partPath } = store.reserve();
    try {
      const size = await new Promise((resolve, reject) => {
        const out = fs.createWriteStream(partPath, { flags: 'wx', mode: 0o600 });
        let received = 0;
        let failed = false;
        const fail = (err) => {
          if (failed) return;
          failed = true;
          out.destroy();
          reject(err);
        };
        req.on('data', (chunk) => {
          if (failed) return;
          received += chunk.length;
          if (received > max) return fail(new AppError(413, 'FILE_TOO_LARGE', `File is larger than the ${Math.floor(max / 1048576)} MB limit.`));
          if (!out.write(chunk)) {
            req.pause();
            out.once('drain', () => req.resume());
          }
        });
        req.on('end', () => !failed && out.end(() => resolve(received)));
        req.on('error', () => fail(new AppError(400, 'UPLOAD_ABORTED', 'The upload was interrupted.')));
        req.on('close', () => !req.complete && fail(new AppError(400, 'UPLOAD_ABORTED', 'The upload was interrupted.')));
        out.on('error', fail);
      });

      const fh = await fsp.open(partPath, 'r');
      const head = Buffer.alloc(64);
      let bytesRead = 0;
      try {
        ({ bytesRead } = await fh.read(head, 0, 64, 0));
      } finally {
        await fh.close();
      }
      const type = sniff(head.subarray(0, bytesRead));
      if (!type) {
        throw new AppError(415, 'UNSUPPORTED_FILE', 'Unsupported file. Upload a JPG, PNG, WebP, GIF, MP4, MOV or WebM file.');
      }
      const filePath = partPath.replace(/\.part$/, `.${type.ext}`);
      await fsp.rename(partPath, filePath);
      try {
        if (type.kind === 'image') await media.validateImage(filePath);
      } catch (err) {
        await fsp.rm(filePath, { force: true });
        throw err;
      }
      const entry = store.add({ id, filePath, name, mime: type.mime, ext: type.ext, kind: type.kind, size });
      h.sendJson(res, 201, publicEntry(entry));
    } catch (err) {
      await fsp.rm(partPath, { force: true });
      throw err;
    }
  }

  async function convert(req, res) {
    const body = await h.readJson(req);
    const entry = store.get(String(body.id || ''));
    if (!entry) throw new AppError(404, 'FILE_NOT_FOUND', 'That file was not found or has expired. Please upload it again.');
    const format = String(body.format || '').toLowerCase();
    if (!media.canConvert(entry, format)) {
      throw new AppError(400, 'UNSUPPORTED_FORMAT', 'That conversion is not available for this file.');
    }
    if (activeConversions >= config.maxConversions) {
      throw new AppError(503, 'BUSY', 'The server is busy converting other files. Please try again in a moment.');
    }
    store.assertCapacity(entry.size);

    const out = MediaService.outputInfo(format);
    const { id, filePath } = store.reserve(format);
    activeConversions += 1;
    try {
      await media.convert(entry, format, filePath);
      const stat = await fsp.stat(filePath);
      const created = store.add({ id, filePath, name: `${stripExt(entry.name)}.${format}`, mime: out.mime, ext: format, kind: out.kind, size: stat.size });
      h.sendJson(res, 201, publicEntry(created));
    } catch (err) {
      await fsp.rm(filePath, { force: true });
      throw err;
    } finally {
      activeConversions -= 1;
    }
  }

  async function serveFile(req, res, { download }) {
    const entry = store.get(req.params.id);
    if (!entry) throw new AppError(404, 'FILE_NOT_FOUND', 'That file was not found or has expired.');
    const size = entry.size;
    let start = 0;
    let end = size - 1;
    let status = 200;
    const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
    if (m && (m[1] || m[2])) {
      if (m[1] === '') start = Math.max(0, size - Number(m[2]));
      else {
        start = Number(m[1]);
        if (m[2]) end = Math.min(end, Number(m[2]));
      }
      if (start > end || start >= size) {
        res.statusCode = 416;
        res.setHeader('Content-Range', `bytes */${size}`);
        return res.end();
      }
      status = 206;
    }
    res.statusCode = status;
    res.setHeader('Content-Type', entry.mime);
    res.setHeader('Content-Length', String(end - start + 1));
    res.setHeader('Accept-Ranges', 'bytes');
    if (status === 206) res.setHeader('Content-Range', `bytes ${start}-${end}/${size}`);
    res.setHeader('Cache-Control', 'private, no-store');
    res.setHeader('Content-Security-Policy', "sandbox; default-src 'none'");
    res.setHeader('Content-Disposition', h.contentDisposition(download ? 'attachment' : 'inline', entry.name));
    if (req.method === 'HEAD') return res.end();
    await pipeline(fs.createReadStream(entry.filePath, { start, end }), res).catch(() => {});
  }

  async function deleteFile(req, res) {
    const removed = store.get(req.params.id) ? await store.remove(req.params.id) : false;
    if (!removed) throw new AppError(404, 'FILE_NOT_FOUND', 'That file was not found or has expired.');
    h.sendJson(res, 200, { ok: true });
  }

  const w = h.wrap;
  const routes = [
    { method: 'get', path: '/api/config', middleware: [apiLimit], handler: w(getConfig) },
    { method: 'get', path: '/api/session', middleware: [apiLimit], handler: w(getSession) },
    { method: 'post', path: '/api/logout', middleware: [apiLimit], handler: w(logout) },
    { method: 'get', path: '/auth/instagram', middleware: [heavyLimit], handler: w(authStart) },
    { method: 'get', path: '/auth/instagram/callback', middleware: [heavyLimit], handler: w(authCallback) },
    { method: 'post', path: '/api/resolve', middleware: [heavyLimit], handler: w(resolve) },
    { method: 'get', path: '/api/ig/item/:id/:variant', middleware: [apiLimit], handler: w(igProxy) },
    { method: 'post', path: '/api/upload', middleware: [heavyLimit], handler: w(upload) },
    { method: 'post', path: '/api/convert', middleware: [heavyLimit], handler: w(convert) },
    { method: 'get', path: '/api/files/:id/preview', middleware: [apiLimit], handler: w((q, s) => serveFile(q, s, { download: false })) },
    { method: 'get', path: '/api/files/:id/download', middleware: [apiLimit], handler: w((q, s) => serveFile(q, s, { download: true })) },
    { method: 'delete', path: '/api/files/:id', middleware: [apiLimit], handler: w(deleteFile) },
  ];

  return { routes, middleware };
}

module.exports = { createRoutes, sanitizeFilename };
