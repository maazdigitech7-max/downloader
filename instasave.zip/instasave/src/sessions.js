'use strict';

const { randomToken } = require('./http');

const MAX_SESSIONS = 5000;
const MAX_ITEMS_PER_SESSION = 500;

/**
 * Server-side sessions. The Instagram access token never reaches the browser:
 * the browser only holds an opaque, HttpOnly session id.
 * In-memory by design; swap for Redis if you run more than one instance.
 */
class SessionStore {
  constructor() {
    this.sessions = new Map();
    this.timer = setInterval(() => this.sweep(), 60 * 1000);
    this.timer.unref();
  }

  create({ accessToken, userId, username, expiresAt }) {
    if (this.sessions.size >= MAX_SESSIONS) this.sweep();
    if (this.sessions.size >= MAX_SESSIONS) {
      // Evict the oldest session rather than refusing new users.
      this.sessions.delete(this.sessions.keys().next().value);
    }
    const id = randomToken(32);
    this.sessions.set(id, { id, accessToken, userId, username, expiresAt, items: new Map() });
    return this.sessions.get(id);
  }

  get(id) {
    const s = this.sessions.get(id);
    if (!s) return null;
    if (s.expiresAt <= Date.now()) {
      this.sessions.delete(id);
      return null;
    }
    return s;
  }

  destroy(id) {
    this.sessions.delete(id);
  }

  /** Remember a downloadable item (opaque id -> upstream URL) for this session only. */
  addItem(session, id, item) {
    if (session.items.size >= MAX_ITEMS_PER_SESSION) {
      session.items.delete(session.items.keys().next().value);
    }
    session.items.set(id, item);
  }

  sweep() {
    const now = Date.now();
    for (const [id, s] of this.sessions) if (s.expiresAt <= now) this.sessions.delete(id);
  }

  close() {
    clearInterval(this.timer);
  }
}

module.exports = { SessionStore };
