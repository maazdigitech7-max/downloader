'use strict';

const path = require('node:path');

/** Load .env (Node >= 20.12). Existing environment variables always win. */
function loadDotEnv() {
  try {
    process.loadEnvFile(path.join(__dirname, '..', '.env'));
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
  }
}

const int = (value, fallback) => {
  const n = Number.parseInt(value, 10);
  return Number.isFinite(n) && n > 0 ? n : fallback;
};

/**
 * Only Instagram/Facebook CDN hosts over HTTPS may be fetched by the media proxy.
 * This is the SSRF guard: URLs come from Instagram's API, and are still checked.
 */
function defaultIsAllowedMediaUrl(value) {
  let u;
  try {
    u = new URL(value);
  } catch {
    return false;
  }
  if (u.protocol !== 'https:' || u.username || u.password || u.port) return false;
  const host = u.hostname.toLowerCase();
  return ['cdninstagram.com', 'fbcdn.net'].some((d) => host === d || host.endsWith('.' + d));
}

function loadConfig(env = process.env) {
  const port = int(env.PORT, 3000);
  const baseUrl = (env.BASE_URL || `http://localhost:${port}`).replace(/\/+$/, '');
  const appId = (env.INSTAGRAM_APP_ID || '').trim();
  const appSecret = (env.INSTAGRAM_APP_SECRET || '').trim();

  return {
    appName: 'InstaSave',
    isProd: env.NODE_ENV === 'production',
    port,
    baseUrl,
    trustProxy: (env.TRUST_PROXY || '').trim(),
    contactEmail: (env.CONTACT_EMAIL || '').trim(),
    instagram: {
      enabled: Boolean(appId && appSecret),
      appId,
      appSecret,
      redirectUri: (env.INSTAGRAM_REDIRECT_URI || `${baseUrl}/auth/instagram/callback`).trim(),
      scope: 'instagram_business_basic',
      apiVersion: env.INSTAGRAM_API_VERSION || 'v25.0',
      authUrl: 'https://www.instagram.com/oauth/authorize',
      tokenUrl: 'https://api.instagram.com/oauth/access_token',
      graphBase: 'https://graph.instagram.com',
      maxPages: int(env.INSTAGRAM_MAX_PAGES, 6),
    },
    upload: {
      dir: path.resolve(env.UPLOAD_DIR || path.join(__dirname, '..', 'tmp')),
      maxBytes: int(env.MAX_UPLOAD_MB, 100) * 1024 * 1024,
      maxStorageBytes: int(env.MAX_STORAGE_MB, 1024) * 1024 * 1024,
      ttlMs: int(env.FILE_TTL_MINUTES, 30) * 60 * 1000,
    },
    ffmpegPath: env.FFMPEG_PATH || 'ffmpeg',
    convertTimeoutMs: int(env.CONVERT_TIMEOUT_SECONDS, 120) * 1000,
    maxConversions: int(env.MAX_CONCURRENT_CONVERSIONS, 2),
    rateLimit: {
      windowMs: 60 * 1000,
      api: int(env.RATE_LIMIT_API, 300),
      heavy: int(env.RATE_LIMIT_HEAVY, 12),
    },
    isAllowedMediaUrl: defaultIsAllowedMediaUrl,
  };
}

module.exports = { loadConfig, loadDotEnv, defaultIsAllowedMediaUrl };
