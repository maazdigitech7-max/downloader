'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { sniff } = require('../src/media');
const { loadConfig } = require('../src/config');
const { defaultIsAllowedMediaUrl } = require('../src/config');
const { sanitizeFilename } = require('../src/routes');
const { makePng, makeJpeg, makeMp4 } = require('./helpers/fixtures');

test('sniff identifies supported types by content and rejects the rest', async () => {
  assert.equal(sniff(await makePng()).ext, 'png');
  assert.equal(sniff(await makeJpeg()).ext, 'jpg');
  assert.equal(sniff(makeMp4()).ext, 'mp4');
  assert.equal(sniff(Buffer.from('GIF89a' + '\0'.repeat(20), 'latin1')).ext, 'gif');
  assert.equal(sniff(Buffer.concat([Buffer.from('RIFF\0\0\0\0WEBPVP8 ', 'latin1'), Buffer.alloc(8)])).ext, 'webp');
  assert.equal(sniff(Buffer.from([0x1a, 0x45, 0xdf, 0xa3, ...new Array(20).fill(0)])).ext, 'webm');
  assert.equal(sniff(Buffer.from('\0\0\0\x18ftypqt  ' + '\0'.repeat(20), 'latin1')).ext, 'mov');
  // not media / disguised files
  assert.equal(sniff(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>')), null);
  assert.equal(sniff(Buffer.from('<html><script>alert(1)</script></html>')), null);
  assert.equal(sniff(Buffer.from('MZ' + '\0'.repeat(40), 'latin1')), null);
  assert.equal(sniff(Buffer.from('\0\0\0\x18ftypheic' + '\0'.repeat(20), 'latin1')), null);
  assert.equal(sniff(Buffer.alloc(0)), null);
  assert.equal(sniff(Buffer.from('short')), null);
});

test('media proxy only allows https Instagram/Facebook CDN hosts', () => {
  const ok = ['https://scontent-sin6-1.cdninstagram.com/v/t51/a.jpg', 'https://video.fbcdn.net/x.mp4', 'https://cdninstagram.com/a'];
  const bad = [
    'http://scontent.cdninstagram.com/a.jpg',
    'https://169.254.169.254/latest/meta-data',
    'https://localhost/a',
    'https://evil.com/cdninstagram.com',
    'https://cdninstagram.com.evil.com/a',
    'https://notcdninstagram.com/a',
    'https://user@scontent.cdninstagram.com/a',
    'https://scontent.cdninstagram.com:8443/a',
    'file:///etc/passwd',
    'not a url',
    '',
  ];
  ok.forEach((u) => assert.equal(defaultIsAllowedMediaUrl(u), true, u));
  bad.forEach((u) => assert.equal(defaultIsAllowedMediaUrl(u), false, u));
});

test('filenames are sanitised', () => {
  assert.equal(sanitizeFilename('../../etc/passwd'), 'etcpasswd');
  assert.equal(sanitizeFilename('..\\..\\win.ini'), 'win.ini');
  assert.equal(sanitizeFilename('a"b<c>d|e?.jpg'), 'abcde.jpg');
  assert.equal(sanitizeFilename('.hidden'), 'hidden');
  assert.equal(sanitizeFilename(''), 'upload');
  assert.equal(sanitizeFilename('x'.repeat(500)).length, 120);
});

test('config reads the environment and never hardcodes secrets', () => {
  const c = loadConfig({});
  assert.equal(c.instagram.enabled, false);
  assert.equal(c.instagram.appSecret, '');
  const d = loadConfig({ INSTAGRAM_APP_ID: '1', INSTAGRAM_APP_SECRET: 's', PORT: '4000', MAX_UPLOAD_MB: '5' });
  assert.equal(d.instagram.enabled, true);
  assert.equal(d.port, 4000);
  assert.equal(d.upload.maxBytes, 5 * 1024 * 1024);
  assert.equal(d.instagram.redirectUri, 'http://localhost:4000/auth/instagram/callback');
});
