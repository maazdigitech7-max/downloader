'use strict';

const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const sharp = require('sharp');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'instasave-fixtures-'));

async function makePng() {
  return sharp({ create: { width: 64, height: 48, channels: 4, background: { r: 124, g: 58, b: 237, alpha: 0.5 } } }).png().toBuffer();
}
async function makeJpeg() {
  return sharp({ create: { width: 64, height: 48, channels: 3, background: '#2563eb' } }).jpeg().toBuffer();
}
function makeMp4() {
  const out = path.join(tmp, 'clip.mp4');
  execFileSync('ffmpeg', ['-y', '-loglevel', 'error', '-f', 'lavfi', '-i', 'testsrc=size=128x96:rate=10:duration=1', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=1', '-shortest', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-movflags', '+faststart', out]);
  return fs.readFileSync(out);
}

module.exports = { makePng, makeJpeg, makeMp4 };
