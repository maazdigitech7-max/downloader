'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs/promises');
const { startApp } = require('./helpers/harness');
const { startFakeInstagram } = require('./helpers/fakeInstagram');
const { makePng, makeJpeg, makeMp4 } = require('./helpers/fixtures');
const { sniff } = require('../src/media');

const JSON_HEADERS = { 'Content-Type': 'application/json' };
const post = (app, path, body, headers = {}) =>
  fetch(app.base + path, { method: 'POST', headers: { ...JSON_HEADERS, ...headers }, body: JSON.stringify(body) });
const cookieOf = (res, name) => {
  const line = res.headers.getSetCookie().find((c) => c.startsWith(name + '='));
  return line ? line.split(';')[0] : null;
};
const upload = (app, buf, name = 'file.bin') =>
  fetch(app.base + '/api/upload', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'X-Filename': encodeURIComponent(name) }, body: buf });

/* =============================== no Instagram config =============================== */

test('config endpoint and graceful "not configured" behaviour', async () => {
  const app = await startApp();
  try {
    const cfg = await (await fetch(app.base + '/api/config')).json();
    assert.equal(cfg.instagram.enabled, false);
    assert.ok(cfg.upload.maxMb > 0);
    assert.deepEqual(cfg.conversions.image, ['jpg', 'png', 'webp']);
    assert.ok(cfg.conversions.video.includes('mp4'));
    assert.equal(JSON.stringify(cfg).includes('secret'), false);

    const r = await post(app, '/api/resolve', { url: 'https://www.instagram.com/p/ABCdef12345/' });
    assert.equal(r.status, 503);
    assert.equal((await r.json()).error.code, 'INSTAGRAM_NOT_CONFIGURED');

    const start = await fetch(app.base + '/auth/instagram', { redirect: 'manual' });
    assert.equal(start.status, 302);
    assert.equal(start.headers.get('location'), '/?auth_error=not_configured');
  } finally {
    await app.close();
  }
});

test('security headers, origin check and request validation', async () => {
  const app = await startApp();
  try {
    const res = await fetch(app.base + '/api/config');
    assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
    assert.match(res.headers.get('content-security-policy'), /frame-ancestors 'none'/);
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(res.headers.get('x-frame-options'), 'DENY');

    const evil = await post(app, '/api/resolve', { url: 'https://www.instagram.com/p/ABCdef12345/' }, { Origin: 'https://evil.example' });
    assert.equal(evil.status, 403);
    assert.equal((await evil.json()).error.code, 'BAD_ORIGIN');

    const same = await post(app, '/api/resolve', { url: 'nope' }, { Origin: app.base });
    assert.equal(same.status, 400);

    for (const [url, code] of [['', 'EMPTY'], ['https://example.com/p/ABCdef12345/', 'NOT_INSTAGRAM'], ['https://www.instagram.com/someuser/', 'UNSUPPORTED_URL']]) {
      const r = await post(app, '/api/resolve', { url });
      assert.equal(r.status, 400, url);
      assert.equal((await r.json()).error.code, code, url);
    }
    const wrongType = await fetch(app.base + '/api/resolve', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: '{"url":"x"}' });
    assert.equal(wrongType.status, 415);
    const badJson = await fetch(app.base + '/api/resolve', { method: 'POST', headers: JSON_HEADERS, body: '{oops' });
    assert.equal(badJson.status, 400);
    assert.equal((await badJson.json()).error.code, 'INVALID_JSON');
    const arr = await post(app, '/api/resolve', [1, 2]);
    assert.equal(arr.status, 400);
    const huge = await post(app, '/api/resolve', { url: 'x'.repeat(40000) });
    assert.equal(huge.status, 413);
  } finally {
    await app.close();
  }
});

test('rate limiting kicks in on heavy endpoints', async () => {
  const app = await startApp({ env: { RATE_LIMIT_HEAVY: '3' } });
  try {
    const statuses = [];
    for (let i = 0; i < 5; i++) statuses.push((await post(app, '/api/resolve', { url: 'bad' })).status);
    assert.deepEqual(statuses, [400, 400, 400, 429, 429]);
    const r = await post(app, '/api/resolve', { url: 'bad' });
    assert.ok(Number(r.headers.get('retry-after')) > 0);
  } finally {
    await app.close();
  }
});

/* ================================= uploads ================================= */

test('upload -> preview -> download round trip returns identical bytes', async () => {
  const app = await startApp();
  try {
    const png = await makePng();
    const res = await upload(app, png, 'My Photo ✨.png');
    assert.equal(res.status, 201);
    const file = await res.json();
    assert.equal(file.kind, 'image');
    assert.equal(file.ext, 'png');
    assert.equal(file.mime, 'image/png');
    assert.equal(file.size, png.length);
    assert.equal(file.name, 'My Photo ✨.png');
    assert.deepEqual(file.convertTo, ['jpg', 'webp']);
    assert.match(file.id, /^[a-f0-9]{32}$/);

    const dl = await fetch(app.base + file.downloadUrl);
    assert.equal(dl.status, 200);
    assert.equal(dl.headers.get('content-type'), 'image/png');
    assert.match(dl.headers.get('content-disposition'), /^attachment; filename="My_Photo__\.png"; filename\*=UTF-8''My%20Photo%20%E2%9C%A8\.png$/);
    assert.match(dl.headers.get('content-security-policy'), /sandbox/);
    assert.ok(Buffer.from(await dl.arrayBuffer()).equals(png));

    const pv = await fetch(app.base + file.previewUrl);
    assert.match(pv.headers.get('content-disposition'), /^inline/);

    // stored on disk with restricted permissions and no user-controlled name
    const names = await fs.readdir(app.dir);
    assert.deepEqual(names, [`${file.id}.png`]);
    assert.equal((await fs.stat(`${app.dir}/${names[0]}`)).mode & 0o777, 0o600);
  } finally {
    await app.close();
  }
});

test('upload rejects unsupported, disguised, corrupt and oversized files and leaves nothing behind', async () => {
  const app = await startApp({ env: { MAX_UPLOAD_MB: '1' } });
  try {
    const cases = [
      ['text file', Buffer.from('hello world, definitely not media'), 'a.png', 415, 'UNSUPPORTED_FILE'],
      ['svg with script named .png', Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'), 'x.png', 415, 'UNSUPPORTED_FILE'],
      ['html named .mp4', Buffer.from('<html><body>hi there</body></html>'), 'x.mp4', 415, 'UNSUPPORTED_FILE'],
      ['empty file', Buffer.alloc(0), 'empty.jpg', 415, 'UNSUPPORTED_FILE'],
      ['corrupt png', Buffer.concat([(await makePng()).subarray(0, 40), Buffer.alloc(100, 7)]), 'bad.png', 415, 'INVALID_IMAGE'],
    ];
    for (const [label, buf, name, status, code] of cases) {
      const r = await upload(app, buf, name);
      assert.equal(r.status, status, label);
      assert.equal((await r.json()).error.code, code, label);
    }
    // declared size over the limit
    const big = await upload(app, Buffer.alloc(1024 * 1024 + 10, 1), 'big.png');
    assert.equal(big.status, 413);
    assert.equal((await big.json()).error.code, 'FILE_TOO_LARGE');

    // chunked upload with no Content-Length that exceeds the limit mid-stream
    const status = await new Promise((resolve, reject) => {
      const req = http.request(app.base + '/api/upload', { method: 'POST', headers: { 'Content-Type': 'application/octet-stream', 'Transfer-Encoding': 'chunked' } }, (res) => { res.resume(); res.on('end', () => resolve(res.statusCode)); });
      req.on('error', reject);
      const chunk = Buffer.alloc(256 * 1024, 2);
      for (let i = 0; i < 6; i++) req.write(chunk);
      req.end();
    });
    assert.equal(status, 413);

    await new Promise((r) => setTimeout(r, 100));
    assert.deepEqual(await fs.readdir(app.dir), [], 'no temp files may remain after rejected uploads');
  } finally {
    await app.close();
  }
});

test('image conversion produces real files in the requested format', async () => {
  const app = await startApp();
  try {
    const file = await (await upload(app, await makePng(), 'pic.png')).json();
    for (const [format, ext, mime] of [['jpg', 'jpg', 'image/jpeg'], ['webp', 'webp', 'image/webp']]) {
      const r = await post(app, '/api/convert', { id: file.id, format });
      assert.equal(r.status, 201, format);
      const out = await r.json();
      assert.equal(out.name, `pic.${ext}`);
      assert.equal(out.mime, mime);
      const bytes = Buffer.from(await (await fetch(app.base + out.downloadUrl)).arrayBuffer());
      assert.equal(sniff(bytes).ext, ext);
      assert.equal(bytes.length, out.size);
    }
    // PNG with alpha -> JPG must flatten onto white, not black
    const sharp = require('sharp');
    const jpg = await (await post(app, '/api/convert', { id: file.id, format: 'jpg' })).json();
    const { data } = await sharp(Buffer.from(await (await fetch(app.base + jpg.downloadUrl)).arrayBuffer())).raw().toBuffer({ resolveWithObject: true });
    assert.ok(data[0] > 150 && data[1] > 100, 'semi-transparent purple should be lightened over white');
  } finally {
    await app.close();
  }
});

test('video upload supports range preview and conversion to webm, mp3 and back to mp4', async () => {
  const app = await startApp();
  try {
    const mp4 = makeMp4();
    const file = await (await upload(app, mp4, 'clip.mp4')).json();
    assert.equal(file.kind, 'video');
    assert.deepEqual(file.convertTo, ['webm', 'mp3']);

    const range = await fetch(app.base + file.previewUrl, { headers: { Range: 'bytes=0-99' } });
    assert.equal(range.status, 206);
    assert.equal(range.headers.get('content-range'), `bytes 0-99/${mp4.length}`);
    assert.equal((await range.arrayBuffer()).byteLength, 100);
    const bad = await fetch(app.base + file.previewUrl, { headers: { Range: `bytes=${mp4.length + 5}-` } });
    assert.equal(bad.status, 416);

    const webm = await (await post(app, '/api/convert', { id: file.id, format: 'webm' })).json();
    assert.equal(webm.mime, 'video/webm');
    const webmBytes = Buffer.from(await (await fetch(app.base + webm.downloadUrl)).arrayBuffer());
    assert.equal(sniff(webmBytes).ext, 'webm');

    const mp3 = await (await post(app, '/api/convert', { id: file.id, format: 'mp3' })).json();
    assert.equal(mp3.kind, 'audio');
    assert.equal(mp3.mime, 'audio/mpeg');
    const mp3Bytes = Buffer.from(await (await fetch(app.base + mp3.downloadUrl)).arrayBuffer());
    assert.ok(mp3Bytes.length > 1000);
    assert.ok(mp3Bytes.subarray(0, 3).toString('latin1') === 'ID3' || (mp3Bytes[0] === 0xff && (mp3Bytes[1] & 0xe0) === 0xe0), 'looks like MP3');

    // chain: webm -> mp4
    const back = await (await post(app, '/api/convert', { id: webm.id, format: 'mp4' })).json();
    assert.equal(back.mime, 'video/mp4');
    const backBytes = Buffer.from(await (await fetch(app.base + back.downloadUrl)).arrayBuffer());
    assert.equal(sniff(backBytes).ext, 'mp4');
  } finally {
    await app.close();
  }
});

test('convert validates input; delete and expiry remove files', async () => {
  const app = await startApp();
  try {
    const file = await (await upload(app, await makePng(), 'a.png')).json();
    const cases = [
      [{ id: 'f'.repeat(32), format: 'jpg' }, 404],
      [{ id: '../../etc/passwd', format: 'jpg' }, 404],
      [{ id: file.id, format: 'png' }, 400], // same format
      [{ id: file.id, format: 'exe' }, 400],
      [{ id: file.id, format: 'mp4' }, 400], // image -> video
      [{ id: file.id }, 400],
    ];
    for (const [body, status] of cases) assert.equal((await post(app, '/api/convert', body)).status, status, JSON.stringify(body));

    for (const bad of ['..%2f..%2fetc%2fpasswd', '%2e%2e', 'zzzz']) {
      assert.equal((await fetch(`${app.base}/api/files/${bad}/download`)).status, 404, bad);
    }

    const del = await fetch(app.base + `/api/files/${file.id}`, { method: 'DELETE' });
    assert.equal(del.status, 200);
    assert.equal((await fetch(app.base + file.downloadUrl)).status, 404);
    assert.equal((await fs.readdir(app.dir)).length, 0);
    assert.equal((await fetch(app.base + `/api/files/${file.id}`, { method: 'DELETE' })).status, 404);

    // expiry
    const f2 = await (await upload(app, await makeJpeg(), 'b.jpg')).json();
    app.store.entries.get(f2.id).expiresAt = Date.now() - 1000;
    assert.equal((await fetch(app.base + f2.downloadUrl)).status, 404);
    await new Promise((r) => setTimeout(r, 50));
    assert.equal((await fs.readdir(app.dir)).length, 0, 'expired file removed from disk');

    const f3 = await (await upload(app, await makeJpeg(), 'c.jpg')).json();
    app.store.entries.get(f3.id).expiresAt = Date.now() - 1;
    await app.store.sweep();
    assert.equal((await fs.readdir(app.dir)).length, 0, 'sweep removes expired files');
  } finally {
    await app.close();
  }
});

test('conversion concurrency limit returns 503 instead of overloading the server', async () => {
  const app = await startApp({ env: { MAX_CONCURRENT_CONVERSIONS: '1' } });
  try {
    const file = await (await upload(app, makeMp4(), 'clip.mp4')).json();
    const [a, b] = await Promise.all([post(app, '/api/convert', { id: file.id, format: 'webm' }), post(app, '/api/convert', { id: file.id, format: 'mp3' })]);
    assert.deepEqual([a.status, b.status].sort(), [201, 503]);
  } finally {
    await app.close();
  }
});

test('storage cap is enforced', async () => {
  const app = await startApp({ env: { MAX_STORAGE_MB: '1', MAX_UPLOAD_MB: '1' } });
  try {
    const png = await makePng();
    app.config.upload.maxStorageBytes = app.store.maxStorageBytes = png.length + 10;
    assert.equal((await upload(app, png, 'a.png')).status, 201);
    const r = await upload(app, png, 'b.png');
    assert.equal(r.status, 503);
    assert.equal((await r.json()).error.code, 'STORAGE_FULL');
  } finally {
    await app.close();
  }
});

/* ============================ Instagram (official API) ============================ */

async function igApp(fake) {
  return startApp({
    env: { INSTAGRAM_APP_ID: 'app-id', INSTAGRAM_APP_SECRET: 'secret' },
    configure: (c) => {
      c.instagram.tokenUrl = `${fake.base}/oauth/access_token`;
      c.instagram.graphBase = fake.base;
      c.isAllowedMediaUrl = (u) => u.startsWith(`${fake.base}/cdn/`);
    },
  });
}

async function connect(app) {
  const start = await fetch(app.base + '/auth/instagram', { redirect: 'manual' });
  const loc = new URL(start.headers.get('location'));
  const stateCookie = cookieOf(start, 'oauth_state');
  const cb = await fetch(`${app.base}/auth/instagram/callback?code=good-code&state=${loc.searchParams.get('state')}`, { redirect: 'manual', headers: { Cookie: stateCookie } });
  return { start, loc, cb, sid: cookieOf(cb, 'sid') };
}

test('OAuth flow: authorize URL, CSRF state, token exchange, session cookie, logout', async () => {
  const fake = await startFakeInstagram();
  const app = await igApp(fake);
  try {
    const { start, loc, cb, sid } = await connect(app);
    assert.equal(start.status, 302);
    assert.equal(loc.origin + loc.pathname, 'https://www.instagram.com/oauth/authorize');
    assert.equal(loc.searchParams.get('client_id'), 'app-id');
    assert.equal(loc.searchParams.get('response_type'), 'code');
    assert.equal(loc.searchParams.get('scope'), 'instagram_business_basic');
    assert.ok(loc.searchParams.get('redirect_uri').endsWith('/auth/instagram/callback'));
    assert.ok(loc.searchParams.get('state').length >= 20);
    assert.match(start.headers.getSetCookie()[0], /HttpOnly/);
    assert.equal(loc.toString().includes('secret'), false, 'secret must never be in the browser URL');

    assert.equal(cb.status, 302);
    assert.equal(cb.headers.get('location'), '/?connected=1');
    assert.ok(sid, 'session cookie set');
    assert.match(cb.headers.getSetCookie().find((c) => c.startsWith('sid=')), /HttpOnly; SameSite=Lax/);
    assert.equal(fake.calls.lastExchange.client_secret, 'secret');
    assert.equal(fake.calls.lastExchange.grant_type, 'authorization_code');

    const session = await (await fetch(app.base + '/api/session', { headers: { Cookie: sid } })).json();
    assert.deepEqual({ connected: session.connected, username: session.username }, { connected: true, username: 'tester' });
    assert.equal(JSON.stringify(session).includes('tok123'), false, 'access token never reaches the browser');
    assert.equal((await (await fetch(app.base + '/api/session')).json()).connected, false);

    const out = await post(app, '/api/logout', {}, { Cookie: sid });
    assert.equal(out.status, 200);
    assert.equal((await (await fetch(app.base + '/api/session', { headers: { Cookie: sid } })).json()).connected, false);
  } finally {
    await app.close();
    await fake.close();
  }
});

test('OAuth callback rejects forged state, missing cookie, denial and bad codes', async () => {
  const fake = await startFakeInstagram();
  const app = await igApp(fake);
  try {
    const start = await fetch(app.base + '/auth/instagram', { redirect: 'manual' });
    const state = new URL(start.headers.get('location')).searchParams.get('state');
    const stateCookie = cookieOf(start, 'oauth_state');
    const hit = async (qs, cookie) => (await fetch(`${app.base}/auth/instagram/callback?${qs}`, { redirect: 'manual', headers: cookie ? { Cookie: cookie } : {} })).headers.get('location');

    assert.equal(await hit(`code=good-code&state=forged`, stateCookie), '/?auth_error=state');
    assert.equal(await hit(`code=good-code&state=${state}`, null), '/?auth_error=state');
    assert.equal(await hit(`code=good-code`, stateCookie), '/?auth_error=state');
    assert.equal(await hit(`error=access_denied&state=${state}`, stateCookie), '/?auth_error=denied');
    assert.equal(await hit(`code=wrong&state=${state}`, stateCookie), '/?auth_error=failed');
    assert.equal(fake.calls.tokenExchanges, 1, 'forged requests must not reach the token endpoint');
  } finally {
    await app.close();
    await fake.close();
  }
});

test('resolve: auth required, own media found (post, reel, carousel), not-owned and unavailable media handled', async () => {
  const fake = await startFakeInstagram();
  const app = await igApp(fake);
  try {
    const anon = await post(app, '/api/resolve', { url: 'https://www.instagram.com/reel/REELCODE123/' });
    assert.equal(anon.status, 401);
    assert.equal((await anon.json()).error.code, 'AUTH_REQUIRED');

    const { sid } = await connect(app);
    const resolve = (url) => post(app, '/api/resolve', { url }, { Cookie: sid });

    // reel on page 2 (pagination works), accepted URL variants
    for (const url of ['https://www.instagram.com/reel/REELCODE123/?igsh=abc', 'https://www.instagram.com/tester/reel/REELCODE123/', 'instagram.com/reels/REELCODE123']) {
      const r = await resolve(url);
      assert.equal(r.status, 200, url);
      const data = await r.json();
      assert.equal(data.type, 'reel');
      assert.equal(data.carousel, false);
      assert.equal(data.items.length, 1);
      assert.equal(data.items[0].mediaType, 'VIDEO');
      assert.deepEqual(data.items[0].formats, ['MP4']);
      assert.equal(JSON.stringify(data).includes(fake.base), false, 'CDN URLs must not leak to the browser');
      assert.equal(JSON.stringify(data).includes('tok123'), false);
    }

    // carousel with image + video children
    const car = await (await resolve('https://www.instagram.com/p/CAROUSEL001/')).json();
    assert.equal(car.carousel, true);
    assert.deepEqual(car.items.map((i) => i.mediaType), ['IMAGE', 'VIDEO']);
    assert.deepEqual(car.items.map((i) => i.formats[0]), ['JPG', 'MP4']);

    // single image
    const img = await (await resolve('https://www.instagram.com/p/OTHERPOST01/')).json();
    assert.equal(img.items[0].mediaType, 'IMAGE');

    // somebody else's post -> honest explanation, no fake success
    const missing = await resolve('https://www.instagram.com/p/NOTMINE0001/');
    assert.equal(missing.status, 404);
    const err = (await missing.json()).error;
    assert.equal(err.code, 'NOT_AVAILABLE');
    assert.match(err.message, /@tester/);

    // Instagram omitted media_url (copyright)
    const copy = await resolve('https://www.instagram.com/reel/COPYRIGHT001/');
    assert.equal(copy.status, 422);
    assert.equal((await copy.json()).error.code, 'MEDIA_UNAVAILABLE');

    // invalid input still validated when logged in
    assert.equal((await resolve('https://example.com/p/ABCdef12345/')).status, 400);
  } finally {
    await app.close();
    await fake.close();
  }
});

test('Instagram media proxy: real bytes, attachment headers, ranges, session binding and SSRF guard', async () => {
  const fake = await startFakeInstagram();
  const app = await igApp(fake);
  try {
    const { sid } = await connect(app);
    const resolve = async (url) => (await post(app, '/api/resolve', { url }, { Cookie: sid })).json();

    const car = await resolve('https://www.instagram.com/p/CAROUSEL001/');
    const [imgItem, vidItem] = car.items;

    const dlImg = await fetch(app.base + imgItem.downloadUrl, { headers: { Cookie: sid } });
    assert.equal(dlImg.status, 200);
    assert.equal(dlImg.headers.get('content-type'), 'image/jpeg');
    assert.equal(dlImg.headers.get('content-disposition'), `attachment; filename="instagram-CAROUSEL001-1.jpg"; filename*=UTF-8''instagram-CAROUSEL001-1.jpg`);
    assert.ok(Buffer.from(await dlImg.arrayBuffer()).equals(fake.jpeg), 'downloaded bytes equal the original');

    const dlVid = await fetch(app.base + vidItem.downloadUrl, { headers: { Cookie: sid } });
    assert.equal(dlVid.headers.get('content-type'), 'video/mp4');
    assert.match(dlVid.headers.get('content-disposition'), /instagram-CAROUSEL001-2\.mp4/);
    const vidBytes = Buffer.from(await dlVid.arrayBuffer());
    assert.ok(vidBytes.equals(fake.mp4));
    assert.equal(sniff(vidBytes).ext, 'mp4');

    // inline preview + poster + Range (needed by Safari for <video>)
    const preview = await fetch(app.base + vidItem.previewUrl, { headers: { Cookie: sid } });
    assert.match(preview.headers.get('content-disposition'), /^inline/);
    await preview.arrayBuffer();
    const range = await fetch(app.base + vidItem.previewUrl, { headers: { Cookie: sid, Range: 'bytes=0-49' } });
    assert.equal(range.status, 206);
    assert.equal((await range.arrayBuffer()).byteLength, 50);
    const poster = await fetch(app.base + vidItem.posterUrl, { headers: { Cookie: sid } });
    assert.equal(poster.headers.get('content-type'), 'image/jpeg');
    await poster.arrayBuffer();

    // items are bound to the session that resolved them
    assert.equal((await fetch(app.base + imgItem.downloadUrl)).status, 401);
    const other = await connect(app);
    assert.equal((await fetch(app.base + imgItem.downloadUrl, { headers: { Cookie: other.sid } })).status, 404);
    assert.equal((await fetch(app.base + '/api/ig/item/000000000000000000000000/media', { headers: { Cookie: sid } })).status, 404);

    // SSRF: API returned a URL outside the CDN allowlist -> refused, never fetched
    const evil = await resolve('https://www.instagram.com/p/EVILURL0001/');
    const blocked = await fetch(app.base + evil.items[0].downloadUrl, { headers: { Cookie: sid } });
    assert.equal(blocked.status, 502);
    assert.equal((await blocked.json()).error.code, 'BLOCKED_HOST');
  } finally {
    await app.close();
    await fake.close();
  }
});

test('expired Instagram session is rejected', async () => {
  const fake = await startFakeInstagram();
  const app = await igApp(fake);
  try {
    const { sid } = await connect(app);
    const id = sid.split('=')[1];
    app.sessions.sessions.get(id).expiresAt = Date.now() - 1;
    const r = await post(app, '/api/resolve', { url: 'https://www.instagram.com/reel/REELCODE123/' }, { Cookie: sid });
    assert.equal(r.status, 401);
    assert.equal(app.sessions.get(id), null);
  } finally {
    await app.close();
    await fake.close();
  }
});
